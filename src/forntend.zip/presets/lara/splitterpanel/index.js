export default {
  root: ({ context }) => ({
    class: ['grow', { flex: context.nested }],
  }),
}
