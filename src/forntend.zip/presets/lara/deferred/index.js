export default {
  root: {},
}
